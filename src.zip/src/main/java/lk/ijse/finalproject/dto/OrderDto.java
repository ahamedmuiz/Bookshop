package lk.ijse.finalproject.dto;

public class OrderDto {
}
