package lk.ijse.finalproject.dto;

public class PaymentDto {
}
