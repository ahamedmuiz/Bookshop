package lk.ijse.finalproject.controller;

public class SalaryController {
}
